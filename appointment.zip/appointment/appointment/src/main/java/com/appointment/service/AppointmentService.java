package com.appointment.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.appointment.dao.AppointmentDAO;
import com.appointment.model.Appointment;
import com.appointment.model.Patient;

@Service
public class AppointmentService {

	@Autowired
	AppointmentDAO appDAO;

	public List<Appointment> getAllAppointments() {
		List<Appointment> appointments = new ArrayList<Appointment>();
		appDAO.findAll().forEach(e -> appointments.add(e));
		return appointments;
	}

	public Optional<Appointment> getAppointmentById(Long id) {
		return appDAO.findById(id);
	}

	public Appointment saveAppointment(Appointment appointment) {
		Appointment result = appDAO.save(appointment);
		return result;
	}

	public List<Appointment> getAppointmentByAppDate(Date appointmentDate) {
		List<Appointment> appointments = new ArrayList<Appointment>();
		appDAO.findByAppDate(appointmentDate).forEach(e -> appointments.add(e));
		
		List<Appointment> appointmentsToReturn = new ArrayList<Appointment>();
		for(int i=0;i <8; i++) {
			Appointment a = new Appointment();
			Patient patient = new Patient();
			patient.setFirstName("Slot Free");
			patient.setLastName("");
			a.setPatient(patient);
			appointmentsToReturn.add(a);
		}
		
		for(Appointment appointment : appointments) {
			int id = appointment.getSlotID()-1;
			appointmentsToReturn.get(id).setAppDate(appointment.getAppDate());
			appointmentsToReturn.get(id).setAppID(appointment.getAppID());
			appointmentsToReturn.get(id).setComplaint(appointment.getComplaint());
			appointmentsToReturn.get(id).setDrID(appointment.getDrID());
			appointmentsToReturn.get(id).setSlotID(appointment.getSlotID());
			Patient patient = new Patient();
			patient.setFirstName(appointment.getPatient().getFirstName());
			patient.setLastName(appointment.getPatient().getLastName());
			patient.setPatientID(appointment.getPatient().getPatientID());
			patient.setPhoneNumber(appointment.getPatient().getPhoneNumber());
			appointmentsToReturn.get(id).setPatient(patient);
			appointmentsToReturn.get(id).setAppDate(appointment.getAppDate());
		}
		return appointmentsToReturn;
	}
}
