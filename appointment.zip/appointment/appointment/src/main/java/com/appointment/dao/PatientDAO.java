package com.appointment.dao;

import org.springframework.data.repository.CrudRepository;

import com.appointment.model.Patient;

public interface PatientDAO extends 
CrudRepository<Patient, Long>{

}
