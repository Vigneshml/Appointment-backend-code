package com.appointment.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.appointment.dao.PatientDAO;
import com.appointment.model.Patient;

@Service
public class PatientService {
	
	@Autowired
	PatientDAO patientDAO;
	
	public List<Patient> getAllPatients() {
		List<Patient> patients = new ArrayList<Patient>();
		patientDAO.findAll().forEach(e -> patients.add(e));
		return patients; 
	}
	
	public Patient savePatient(Patient patient) {
		Patient result = patientDAO.save(patient);
		return result;
	}
	
	public Optional<Patient> getPatientById(Long id) {
	return patientDAO.findById(id);
	}


}
