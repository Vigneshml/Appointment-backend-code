package com.appointment.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.appointment.model.Appointment;

public interface AppointmentDAO extends 
CrudRepository<Appointment, Long>{
	
	List<Appointment> findByAppDate(Date appointmentDate);

}
