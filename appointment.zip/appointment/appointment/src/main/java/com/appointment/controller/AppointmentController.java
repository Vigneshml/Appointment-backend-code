package com.appointment.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.appointment.model.Appointment;
import com.appointment.service.AppointmentService;

@RestController
public class AppointmentController {

	@Autowired
	AppointmentService appService;

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/appointments")
	List<Appointment> getAllAppointments() {
		return appService.getAllAppointments();
	}
	
	@GetMapping("/appointment/{id}")
	ResponseEntity<Optional<Appointment>> getAppointmentById(@PathVariable(value = "id") Long appointmentID) {
		Optional<Appointment> appointment =  appService.getAppointmentById(appointmentID);
		return ResponseEntity.ok().body(appointment);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/appointment/date/{date}")
	List<Appointment> getAppointmentByDate(@PathVariable(value = "date") String appointmentDate) throws ParseException {
		return appService.getAppointmentByAppDate(new SimpleDateFormat("yyyy-MM-dd").parse(appointmentDate));
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/appointment")
	Appointment createAppointment(@RequestBody Appointment appointment) {
		return appService.saveAppointment(appointment);
	}

}
