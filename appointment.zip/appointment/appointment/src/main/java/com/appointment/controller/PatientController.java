package com.appointment.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.appointment.model.Patient;
import com.appointment.service.PatientService;

@RestController
public class PatientController {

	@Autowired
	PatientService patientService;

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/patients")
	List<Patient> getAllPatients() {
		return patientService.getAllPatients();
	}
	
	@GetMapping("/patient/{id}")
	ResponseEntity<Optional<Patient>> getPatientById(@PathVariable(value = "id") Long patientID) {
		Optional<Patient> patient =  patientService.getPatientById(patientID);
		return ResponseEntity.ok().body(patient);
	}

	@PostMapping("/patient")
	Patient createNewPatient(@RequestBody Patient patient) {
		return patientService.savePatient(patient);
	}

}
